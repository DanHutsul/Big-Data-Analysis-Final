from distutils.core import setup
setup(name="Positive_Counter_Bot",
      version="1.0.0",
      py_modules=['main'],
      packages=['Positive_Counter_Botkg'])