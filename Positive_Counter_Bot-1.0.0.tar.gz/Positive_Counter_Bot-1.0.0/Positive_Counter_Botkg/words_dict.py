import praw
import string

class words_dict:

    def __init__(self, submission):
        """Initializes the class

        This class stores the given submission and 2 dictionaries
        with positive and negative words

        Args:
            submission (submission): submission instance

        """
        self.submission = submission

        # Dictionary key: Word
        # Dectionary value: amount of this word in comments
        self.negative = dict()
        self.positive = dict()

        # Two files are required
        with open("negative-words.txt", "r") as f:
            self.negative_words = f.read()
        with open("positive-words.txt", "r") as f:
            self.positive_words = f.read()

    def get(self):
        """Scans the comment section for words with emotional values
        """
        # Get all words
        words = self._simplify()
        for word in words:
            if self._negative(word):
                if word not in self.negative:
                    self.negative[word] = 1
                else:
                    self.negative[word] += 1

            elif self._positive(word):
                if word not in self.positive:
                    self.positive[word] = 1
                else:
                    self.positive[word] += 1

    def _simplify(self):
        """Processes comment section

        Reads all comments from a submission
        Returns a list containing all words

        Returns:
            list: List containing all words in comment section
        """
        submissionList = []
        temp = self.submission
        temp.comments.replace_more(limit=None)
        for comment in temp.comments.list():
            submissionList.append(comment.body)
        words_list = []
        for comment in submissionList:
            replacement = string.punctuation.replace("-", "")
            comment = comment.translate(str.maketrans('', '', replacement))
            res = comment.split()
            for i in res:
                words_list.append(i.lower())
        return words_list

    def _negative(self, word):
        """Check if word is negative

        Determines whether the word is negative
        
        Args:
            word (str): word to be checked
        
        Returns:
            bool: result of the check
        """
        if self._search("negative-words.txt", word):
            return True
        return False

    def _positive(self, word):
        """Check if word is positive
        
        Determines whether the word is positive

        Args:
            word (str): word to be checked
        
        Returns:
            bool: result of the check
        """
        if self._search("positive-words.txt", word):
            return True
        return False

    def _search(self, file, word):
        """Searches the file

        Determines whether the word is present in the file

        Args:
            file (str): file name
            word (str): word to be checked
        
        Returns:
            bool: result of the check
        """
        with open(file, "r") as f:
            for line in f:
                if line[:-1] == word:
                    return True
            return False