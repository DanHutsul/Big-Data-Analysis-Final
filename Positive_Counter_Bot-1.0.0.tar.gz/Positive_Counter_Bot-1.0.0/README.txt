Positive_Counter_Bot
An autonomous bot that measures the positivity of Reddit comment threads

Usage
Download positive-words.txt and negative-words.txt from https://github.com/DanHutsul/Data-Analysis-Final and place them in the same folder with words_dict.py

Distributed under the MIT License. See LICENSE for more information.

Contact
dan.hutsul@gmail.com
